import pygame
from PIL import Image
img = Image.open('maze.png')
img.show()